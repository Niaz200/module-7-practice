<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;




// Route::post('/user', [ProfileController::class, 'user']);

Route::get('/', function(){
    return "From Admin Route";
});

Route::get('/profile', function(){
    return "From Admin Profile";
});
