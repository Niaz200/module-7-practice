<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function index(){
        $data = [
            'name' => 'John Doe',
            'age' => '25',
            'city' => 'New York',
            'country' => 'USA'
        ];

        return $data;
    }


    public function store(Request $request){
        $data = [
            'name' => $request->name,
            'age' => $request->age,
            'city' => $request->city,

        ];

        return $data;
    }


    public function user(Request $request){

        return $request->all();


        // $data = [
        //     'name' => $request->name,
        //     'age' => $request->age,
        //     'city' => $request->city,

        // ];

        // return $data;
    }


}
