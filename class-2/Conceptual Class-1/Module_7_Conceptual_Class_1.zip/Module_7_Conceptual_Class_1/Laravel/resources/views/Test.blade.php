<div>
{{-- <h1>Test View {{ $id }} {{ $data }}</h1> --}}
<a href="{{ route('post') }}">Send</a>
</div>
