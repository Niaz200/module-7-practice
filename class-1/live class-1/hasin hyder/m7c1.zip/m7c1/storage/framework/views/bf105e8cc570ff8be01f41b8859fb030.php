<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel 10</title>
</head>
<body>

   
    

     <h1>Hello from View</h1>
    <h2>Location = <?php echo e($location['name']); ?></h2>
   
   

   <h2>Seasons = <?php echo e(join(",",$seasons)); ?></h2> 
    
</body>
</html><?php /**PATH C:\xampp\htdocs\m7c1\resources\views/lc.blade.php ENDPATH**/ ?>