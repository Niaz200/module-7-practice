<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel 10 Weather</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

<h1>Weather Report</h1>
<h2>Location = <?php echo e($location); ?></h2>
<h2>Temperature = <?php echo e($currentTemp); ?> Degree Celcius</h2>
<h2>Weather Condition = <?php echo e($currentCondition); ?></h2>

<img width="500" src="<?php echo e(asset('images/cloud.jpg')); ?>" alt="">

    
</body>
</html><?php /**PATH C:\xampp\htdocs\m7c1\resources\views/weather.blade.php ENDPATH**/ ?>